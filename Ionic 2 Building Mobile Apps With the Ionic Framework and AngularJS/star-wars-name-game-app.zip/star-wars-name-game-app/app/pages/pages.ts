export * from './home/home';
export * from './word-entry/word-entry.page';
export * from './data-bank/data-bank.page'
export * from './word-history/word-history.modal';
export * from './entry-detail/entry-detail.modal';