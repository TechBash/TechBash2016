import { Component } from '@angular/core';
import { ModalController, NavController } from 'ionic-angular';
import * as _ from 'lodash';

import { EntryDetailModal } from '../pages';
import { GameService } from '../../services/services';

@Component({
  templateUrl: 'build/pages/data-bank/data-bank.page.html',
})
export class DataBankPage {

  data: any[];
  entries: any[];
  queryText: string;

  constructor(
    private modalController: ModalController,
    private nav: NavController,
    private gameService: GameService) { }

  ionViewLoaded(){
    this.data = this.gameService.getFullDataBank();
    this.entries = this.data;
  }

  getHeader(record, recordIndex, records){
    let firstCharacter = record.title[0].toUpperCase();
    if (recordIndex === 0 || firstCharacter !== records[recordIndex-1].title[0].toUpperCase()){
      return firstCharacter;
    }
    return null;
  }

  viewDetail(entry){
    let modal = this.modalController.create(EntryDetailModal, entry);
    modal.present();
  }

  updateEntries(){
    let queryTextLower = this.queryText.toLowerCase();
    this.entries = _.filter(this.data, x => x.title.toLowerCase().includes(queryTextLower));
  }
}