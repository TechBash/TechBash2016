import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { DataBankPage, WordEntryPage } from '../pages';

@Component({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage {
  constructor(public nav: NavController) { }
  
  goToPlayNow(){
    this.nav.push(WordEntryPage);
  }

  goToDataBank(){
    this.nav.push(DataBankPage);
  }
}
