import { Component } from '@angular/core';
import { AlertController, ModalController, NavController, ToastController } from 'ionic-angular';
import * as _ from 'lodash';

import { GameService } from '../../services/services';
import { HomePage, WordHistoryModal } from '../pages';

@Component({
  templateUrl: 'build/pages/word-entry/word-entry.page.html',
})
export class WordEntryPage {
  private turnData: any = {};
  wordInput: string;

  constructor(
    private alertController: AlertController,
    private modalController: ModalController,
    private nav: NavController,
    private toastController: ToastController,
    private gameService: GameService) {
    this.turnData = this.gameService.getTurnData();
  }

  checkWordHistory(){
    let modal = this.modalController.create(WordHistoryModal, this.gameService.getWordHistory());
    modal.present();
  }

  submitWord(){
    let validationResult = this.gameService.isValidWord(this.wordInput);
    if (!validationResult.valid){
      let toast = this.toastController.create({
        message: `${validationResult.title} - ${validationResult.subTitle}`,
        duration: 2000,
        showCloseButton: true
      });
      toast.present();
      return;
    }

    let result = this.gameService.checkWord(this.wordInput);
    if (result){
      let alert = this.alertController.create({
        title: 'Correct',
        subTitle: `"${this.wordInput}" was found for "${result.title}"!"`,
        buttons: [
          {
            text: 'OK',
            handler: () => {
              this.turnData = this.gameService.nextTurn(this.wordInput, result);
              this.wordInput = '';
            }
          }
        ]
      });
      alert.present();
    } else {
      let alert = this.alertController.create({
        title: 'Not Found',
        subTitle: `"${this.wordInput}" was not found!"`,
        buttons: ['OK']
      });
      alert.present();
    }
  }
}
