import { Injectable } from '@angular/core';
let data = <DataBankItem[]>require('../data/star-wars-data');
import * as _ from 'lodash';

@Injectable()
export class GameService {
    private gameEntries: { inputTerm: string, entry: DataBankItem }[] = [];

    constructor() { }

    checkWord(input:string){
        let wordToCheck = input.toLowerCase();
        let result = _.find(data, x => {
            let titleToCheck = x.title.toLowerCase();
            // First check for exact match
            if (titleToCheck === wordToCheck){
                return true;
            }

            // Exact match not found so check word parts
            let terms = x.title.toLowerCase().split(' ');
            return _.includes(terms, wordToCheck);
        });
        return result;
    }

    getFullDataBank(){
        return data;
    }

    getTurnData(){
        return {
            wordCount: this.gameEntries.length,
            lastEntry: _.last(this.gameEntries)
        };
    }

    getWordHistory(){
        return this.gameEntries;
    }

    isValidWord(wordInput: string): ValidationInfo{
        // Check that word was supplied
        if (!wordInput){
            return {
                title: 'Missing Entry',
                subTitle: 'You did not specifiy a word!',
                valid: false
            };
        }

        // Check if first character is correct
        let turnData = this.getTurnData();
        if (turnData.lastEntry) {
            let lastLetterLastTurn = _.last(turnData.lastEntry.inputTerm).toUpperCase();
            let firstLetterThisTurn = _.first(wordInput).toUpperCase();
            if (lastLetterLastTurn !== firstLetterThisTurn) {
                return {
                    title: 'Invalid First Letter',
                    subTitle: `Your first letter must be: ${lastLetterLastTurn}!`,
                    valid: false
                }
            }
        }

        // Check if term has already been used
        let wordHistory = this.getWordHistory();
        let lowerInput = wordInput.toLowerCase();
        let previouslyUsed = _.find(wordHistory, x => x.inputTerm.toLowerCase() === lowerInput);
        if (previouslyUsed) {
            return {
                title: 'Previously Used',
                subTitle: `This was already used: ${wordInput}. Please try again!`,
                valid: false
            };
        }

        return { valid: true };
    }

    nextTurn(successfulTerm: string, entry: DataBankItem){
        this.gameEntries.push({ inputTerm: successfulTerm, entry: entry });
        return this.getTurnData();
    }

    resetGame(){
        this.gameEntries = [];
    }
}

interface DataBankItem{
    title: string,
    desc: string
}

interface ValidationInfo{
    title?: string,
    subTitle?: string,
    valid: boolean
}