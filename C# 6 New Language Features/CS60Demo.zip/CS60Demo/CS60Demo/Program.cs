﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
// C#6 feature: Using Static
using static System.Console;

namespace CS60Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //var contact = new Contact { FirstName = "Bill", LastName = "Gates" };
            //// C#6 feature: Using Static 
            //WriteLine(contact);

            //WriteLine(contact.FullName);
            //contact.Echo("Hello cmap");
            //WriteLine(contact.Yell("hello cmap!"));

            //var dict = InitContactDictionary();
            //PrintList(dict.Values);

            //var list = InitContactsCollection();
            //PrintList(list);

            //Contact contact = null;
            //var valid = contact.IsMaxLengthValid();
            //Console.WriteLine("Valid: " + valid);

            //ReadFileAsync();
            //Console.ReadLine();
            
            ExecuteRoslyn();
            Console.ReadLine();
        }

        private static void ExecuteRoslyn()
        {
            var code = File.ReadAllText("Person.txt");
            var tree = SyntaxFactory.ParseSyntaxTree(code);

            // Create Compilation
            var options = new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary);
            var reference = MetadataReference.CreateFromFile(typeof(object).Assembly.Location);
            var compilation = CSharpCompilation.Create("test")
                .WithOptions(options)
                .AddSyntaxTrees(tree)
                .AddReferences(reference);

            // Show Diagnostics
            var diagnostics = compilation.GetDiagnostics();
            foreach (var item in diagnostics)
            {
                Console.WriteLine(item.ToString());
            }

            // Execute Code
            using (var stream = new MemoryStream())
            {
                compilation.Emit(stream);
                var assembly = Assembly.Load(stream.GetBuffer());
                var type = assembly.GetType("CS60Demo.Person");
                //var person = Activator.CreateInstance(type);
                //var method = type.GetMethod("SayHello");
                //method.Invoke(person, null);
                dynamic person = Activator.CreateInstance(type);
                person.SayHello();
            }
        }

        private static async void ReadFileAsync()
        {
            var filename = "test2.txt";

            try
            {
                var result = await FileUtil.ReadFileAsync(filename);
                Console.WriteLine(result);
            }
            // C#6 feature: Exception Filter
            catch (FileNotFoundException ex) when (ex.FileName.EndsWith(".txt"))
            {
                await FileUtil.LogAsync($"File not found: {ex.FileName}");
            }
            catch (Exception)
            {
                // C#6 feature: await inside catch (or finally)
                await FileUtil.LogAsync("Unknown Error.");
            }
        }

        static ContactsCollection InitContactsCollection()
        {
            var contacts = new ContactsCollection
            {
                new Contact { FirstName = "George", LastName = "Washington" },
                new Contact { FirstName = "John", LastName = "Adams" },
                new Contact { FirstName = "Thomas", LastName = "Jefferson" }
            };
            return contacts;
        }

        static Dictionary<int, Contact> InitContactDictionary()
        {
            var contacts = new Dictionary<int, Contact>
            {
                //{ 1, new Contact { FirstName = "George", LastName = "Washington" } },
                //{ 2, new Contact { FirstName = "John", LastName = "Adams" } },
                //{ 3, new Contact { FirstName = "Thomas", LastName = "Jefferson" } }
                // C#6 feature: Dictionary Initializers (new way)
                [1] = new Contact { FirstName = "George", LastName = "Washington" },
                [2] = new Contact { FirstName = "John", LastName = "Adams" },
                [3] = new Contact { FirstName = "Thomas", LastName = "Jefferson" }
            };
            return contacts;
        }

        static void PrintList(IEnumerable<Contact> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }
    }
}
