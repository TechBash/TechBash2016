﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CS60Demo
{
    public static class FileUtil
    {
        public static async Task<string> ReadFileAsync(string filePath)
        {
            byte[] result;

            using (FileStream sourceStream = File.Open(filePath, FileMode.Open))
            {
                result = new byte[sourceStream.Length];
                await sourceStream.ReadAsync(result, 0, (int)sourceStream.Length);
                var rawString = Encoding.UTF8.GetString(result);
                return rawString;
            }
        }

        public static async Task LogAsync(string message)
        {
            byte[] encodedText = Encoding.UTF8.GetBytes($"{DateTime.Now.ToString()} {message}{Environment.NewLine}");
            const string logFilePath = @"log.txt";

            using (FileStream sourceStream = new FileStream(logFilePath,
                FileMode.Append, FileAccess.Write, FileShare.None,
                bufferSize: 4096, useAsync: true))
            {
                Console.WriteLine(message);
                await sourceStream.WriteAsync(encodedText, 0, encodedText.Length);
            };
        }
    }
}