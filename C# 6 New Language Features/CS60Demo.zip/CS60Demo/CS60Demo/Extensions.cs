﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS60Demo
{
    static class Extensions
    {
        public static bool IsMaxLengthValid(this Contact contact)
        {
            if (contact == null)
            {
                // C#6 feature: nameof operator
                throw new ArgumentNullException(nameof(contact));
            }
            //if (contact != null && contact.LastName != null)
            //{
            //    var length = contact.LastName.Length;
            //    return length <= 20;
            //}
            //else
            //{
            //    return true;
            //}

            // C#6 feature: Null Conditional Access
            var length = contact?.LastName?.Length ?? 0;
            return length <= 20;
        }

        // C#6 feature: Add Extension for Collection Initializer
        public static Contact Add(this ContactsCollection list, Contact contact)
        {
            return list.Insert(contact);
        }
    }
}
