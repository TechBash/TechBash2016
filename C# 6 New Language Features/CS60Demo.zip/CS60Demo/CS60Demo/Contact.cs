﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS60Demo
{
    public class Contact
    {
        // C#6 feature: Auto-Property Initializer (with Getting only)
        public Guid Id { get; } = Guid.NewGuid();

        public string FirstName { get; set; }
        public string LastName { get; set; }

        // C#6 feature: Expression Bodied Member (property)
        public string FullName => $"{this.FirstName} {this.LastName}";

        // C#6 feature: EBM (void method)
        public void Echo(string message) => Console.WriteLine($"This message is: {message}");

        // C#6 feature: EBM (method that returns)
        public string Yell(string message) => message.ToUpper();

        public override string ToString()
        {
            //return string.Format("{0} {1} ({2})", this.FirstName, this.LastName, this.Id);
            
            // C#6 feature: String Interpolation
            return $"{this.FirstName} {this.LastName} ({this.Id})";
            
            //FormattableString name = $"{this.FirstName} {this.LastName} ({this.Id})";
            //Console.WriteLine(name.ArgumentCount + ", " + name.Format);
            //return name.ToString();
        }

    }
}
