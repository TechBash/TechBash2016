﻿using System.Collections;
using System.Collections.Generic;

namespace CS60Demo
{
    public class ContactsCollection : IEnumerable<Contact>
    {
        private List<Contact> list = new List<Contact>();

        public IEnumerator<Contact> GetEnumerator()
        {
            return list.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public Contact Insert(Contact contact)
        {
            this.list.Add(contact);
            return contact;
        }
    }
}